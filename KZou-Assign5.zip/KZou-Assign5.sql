-- Assignment 5 - SQL Queries

-- 1
SELECT quantityOnHand
FROM item
WHERE itemDescription = 'bottle of antibiotics';

-- 2
SELECT DISTINCT volunteerName
FROM volunteer
WHERE volunteerTelephone IS NOT NULL
    AND volunteerTelephone NOT LIKE '2%'
    AND volunteerName NOT LIKE '% Jones';

-- 3
SELECT DISTINCT v.volunteerName
FROM volunteer AS v
JOIN assignment AS a
    ON v.volunteerId = a.volunteerId
JOIN task AS t
    ON a.taskCode = t.taskCode
JOIN task_type AS tt
    ON t.taskTypeId = tt.taskTypeId
WHERE tt.taskTypeName = 'transporting';

-- 4
SELECT t.taskDescription
FROM task AS t
WHERE NOT EXISTS (
    SELECT 1
    FROM assignment AS a
    WHERE a.taskCode = t.taskCode
);

-- 5
SELECT DISTINCT pt.packageTypeName
FROM package_type AS pt
JOIN package AS p
    ON pt.packageTypeId = p.packageTypeId
JOIN package_contents AS pc
    ON p.packageId = pc.packageId
JOIN item AS i
    ON pc.itemId = i.itemId
WHERE i.itemDescription LIKE '%bottle%';

-- 6
SELECT i.itemDescription
FROM item AS i
WHERE NOT EXISTS (
    SELECT 1
    FROM package_contents AS pc
    WHERE pc.itemId = i.itemId
);

-- 7
SELECT DISTINCT t.taskDescription
FROM task AS t
JOIN assignment AS a
    ON t.taskCode = a.taskCode
JOIN volunteer AS v
    ON a.volunteerId = v.volunteerId
WHERE v.volunteerAddress LIKE '%NJ%';

-- 8
SELECT DISTINCT v.volunteerName
FROM volunteer AS v
JOIN assignment AS a
    ON v.volunteerId = a.volunteerId
WHERE a.startDateTime >= '2021-01-01'
    AND a.startDateTime < '2021-07-01';

-- 9
SELECT DISTINCT v.volunteerName
FROM volunteer AS v
JOIN assignment AS a
    ON v.volunteerId = a.volunteerId
JOIN package AS p
    ON a.taskCode = p.taskCode
JOIN package_contents AS pc
    ON p.packageId = pc.packageId
JOIN item AS i
    ON pc.itemId = i.itemId
WHERE i.itemDescription = 'can of spam';

-- 10
SELECT DISTINCT i.itemDescription
FROM item AS i
JOIN package_contents AS pc
    ON i.itemId = pc.itemId
WHERE i.itemValue * pc.itemQuantity = 100;

-- 11
SELECT ts.taskStatusName, COUNT(DISTINCT a.volunteerId) AS volunteerCount
FROM task_status AS ts
LEFT JOIN task AS t
    ON ts.taskStatusId = t.taskStatusId
LEFT JOIN assignment AS a
    ON t.taskCode = a.taskCode
GROUP BY ts.taskStatusId, ts.taskStatusName
ORDER BY volunteerCount DESC;

-- 12
SELECT p.taskCode, SUM(p.packageWeight) AS totalWeight
FROM package AS p
GROUP BY p.taskCode
ORDER BY totalWeight DESC
LIMIT 1;

-- 13
SELECT COUNT(*) AS taskCount
FROM task AS t
JOIN task_type AS tt
    ON t.taskTypeId = tt.taskTypeId
WHERE tt.taskTypeName <> 'packing';

-- 14
SELECT i.itemDescription
FROM item AS i
JOIN package_contents AS pc
    ON i.itemId = pc.itemId
JOIN package AS p
    ON pc.packageId = p.packageId
LEFT JOIN assignment AS a
    ON p.taskCode = a.taskCode
GROUP BY i.itemId, i.itemDescription
HAVING COUNT(DISTINCT a.volunteerId) < 3;

-- 15
SELECT pc.packageId, SUM(pc.itemQuantity * i.itemValue) AS totalValue
FROM package_contents AS pc
JOIN item AS i
    ON pc.itemId = i.itemId
GROUP BY pc.packageId
HAVING SUM(pc.itemQuantity * i.itemValue) > 100
ORDER BY totalValue ASC;
